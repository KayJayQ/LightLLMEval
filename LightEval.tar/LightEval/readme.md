# Light Eval: A simple LLM metric evaluator

Light Eval is a simple LLM metric evaluator that allows you to evaluate your LLM output against a set of metrics. It is designed to be easy to use and support multi executors, such as huggginface transformers and vllm.

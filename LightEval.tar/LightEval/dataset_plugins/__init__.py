from .math500 import Math500

__all__ = [
    "Math500",
]
